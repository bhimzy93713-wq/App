# Skill Coach (Android)

A small native Android app for the user's 3-day handstand + planche workout. Includes exercise cues, check-offs saved locally, rest countdowns, and day-by-day routines.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `SkillCoach` folder as an existing project.
3. Allow Gradle sync/downloads to finish (requires internet the first time).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. If Android asks, allow installation from that file manager/browser.

Requirements: Android Studio with JDK 17+ and Android SDK Platform 35 installed. The project uses no third-party libraries. This environment did not have Android SDK/Gradle installed, so the APK has not been compiled here.
