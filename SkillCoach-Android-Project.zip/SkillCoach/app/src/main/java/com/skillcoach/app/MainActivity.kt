package com.skillcoach.app

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

private data class Exercise(val name: String, val sets: String, val target: String, val rest: Int, val cue: String)

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 25)
    private val panel = Color.rgb(25, 32, 46)
    private val accent = Color.rgb(95, 230, 174)
    private val white = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(169, 181, 198)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var timerText: TextView
    private lateinit var timerButton: Button
    private var timer: CountDownTimer? = null
    private var remaining = 60
    private var activeDay = 1
    private val done = mutableSetOf<String>()
    private val prefs by lazy { getSharedPreferences("skillcoach", MODE_PRIVATE) }

    private val plans = mapOf(
        1 to listOf(
            Exercise("Wall handstand hold", "4 sets", "20–40 sec", 90, "Push tall through your shoulders. Keep ribs tucked; stop before form breaks."),
            Exercise("Handstand balance attempts", "5 sets", "10–20 sec", 75, "Practise controlled entries and small balance corrections. Learn a safe exit first."),
            Exercise("Planche leans", "4 sets", "12–20 sec", 90, "Elbows straight, shoulders forward, shoulder blades pushed apart."),
            Exercise("Pseudo-planche push-ups", "3 sets", "5–8 reps", 120, "Lean forward while keeping elbows controlled. Use an easier range if needed."),
            Exercise("Pike push-ups", "3 sets", "5–8 reps", 105, "Lower slowly and press up without forcing your neck."),
            Exercise("Hollow-body hold", "3 sets", "20–30 sec", 60, "Keep lower back pressed into the floor.")),
        2 to listOf(
            Exercise("Chest-to-wall handstand", "3 sets", "20–35 sec", 90, "Keep your body aligned and push tall through your shoulders."),
            Exercise("Tuck-planche progression", "4 sets", "5–10 sec", 120, "Only lift feet if elbows stay straight and the position is controlled; otherwise do planche leans."),
            Exercise("Scapular push-ups", "3 sets", "10–15 reps", 60, "Keep elbows straight and move through the shoulder blades."),
            Exercise("Wall handstand shoulder shrugs", "3 sets", "8–12 reps", 90, "Elevate shoulders without bending elbows; stay near the wall."),
            Exercise("Side plank", "3 sets", "25–35 sec per side", 60, "Keep hips lifted and body aligned."),
            Exercise("Reverse snow angels", "3 sets", "10–15 reps", 60, "Move slowly to work the upper back and rear shoulders.")),
        3 to listOf(
            Exercise("Freestanding handstand practice", "6 sets", "10–20 sec attempts", 75, "Focus on controlled entries, balance and safe exits, not kicking harder."),
            Exercise("Planche leans", "4 sets", "15–25 sec", 90, "Lean only as far as you can keep straight elbows and stable shoulders."),
            Exercise("Pike push-ups", "3 sets", "5–8 reps", 105, "Slow, controlled reps. Stop if shoulder or wrist pain appears."),
            Exercise("Pseudo-planche push-ups", "3 sets", "5–8 reps", 120, "Keep hands planted and lean only within your current ability."),
            Exercise("Hollow-body hold", "3 sets", "25–35 sec", 60, "Brace your core and keep your lower back down."),
            Exercise("Wrist and shoulder mobility", "2 rounds", "30 sec per movement", 30, "Gentle wrist rocks and shoulder mobility; never force a painful stretch."))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        done.addAll(prefs.getStringSet("done", emptySet()) ?: emptySet())
        buildScreen()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value; isAllCaps = false; setTextColor(white); background = rounded(Color.rgb(44, 57, 75), 14); setOnClickListener { action() }
    }
    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(18), dp(18), dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(14)) }
        header.addView(text("SKILL COACH", 27f, accent, true))
        header.addView(text("HANDSTAND  ×  PLANCHE", 13f, muted, true))
        header.addView(text("3 DAYS / WEEK  •  NO EQUIPMENT", 12f, muted).apply { setPadding(0, dp(7), 0, 0) })
        root.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 3f }
        for (d in 1..3) {
            val b = button("DAY $d") { activeDay = d; renderDay() }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        }
        root.addView(tabs)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, dp(16)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderDay()
    }

    private fun renderDay() {
        content.removeAllViews()
        val title = when (activeDay) { 1 -> "Balance + strength"; 2 -> "Planche + technique"; else -> "Combine both skills" }
        content.addView(text("Day $activeDay · $title", 20f, white, true).apply { setPadding(0, dp(3), 0, dp(10)) })
        val list = plans[activeDay] ?: return
        list.forEachIndexed { i, ex ->
            val key = "$activeDay-$i"
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(panel); setPadding(dp(14), dp(12), dp(14), dp(12))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val label = text(if (done.contains(key)) "✓  ${ex.name}" else ex.name, 16f, white, true)
            val check = CheckBox(this).apply {
                isChecked = done.contains(key); buttonTintList = android.content.res.ColorStateList.valueOf(accent); setTextColor(white)
                setOnCheckedChangeListener { _, checked -> if (checked) done.add(key) else done.remove(key); prefs.edit().putStringSet("done", done.toSet()).apply(); label.text = if (checked) "✓  ${ex.name}" else ex.name; updateHeader() }
            }
            check.text = ""
            row.addView(check)
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row)
            card.addView(text("${ex.sets}   •   ${ex.target}", 13f, accent, true).apply { setPadding(dp(4), dp(4), 0, dp(8)) })
            card.addView(text(ex.cue, 14f, muted).apply { setPadding(dp(4), 0, 0, dp(8)) })
            card.addView(button("Start ${ex.rest}s rest timer") { startTimer(ex.rest) })
            content.addView(card)
        }
        val timerCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.rgb(30, 42, 55)); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        timerCard.addView(text("REST TIMER", 13f, accent, true))
        timerText = text(formatTime(remaining), 34f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(8)) }
        timerCard.addView(timerText)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("−15s") { remaining = (remaining - 15).coerceAtLeast(0); timerText.text = formatTime(remaining) }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        timerButton = button("Start timer") { startTimer(remaining) }
        controls.addView(timerButton, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        controls.addView(button("+15s") { remaining = (remaining + 15).coerceAtMost(300); timerText.text = formatTime(remaining) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        timerCard.addView(controls)
        content.addView(timerCard)
        content.addView(text("Progress: ${done.count { it.startsWith("$activeDay-") }}/${list.size} exercises checked", 13f, muted).apply { setPadding(0, dp(10), 0, dp(5)) })
        content.addView(button("Reset this day") { list.indices.forEach { done.remove("$activeDay-$it") }; prefs.edit().putStringSet("done", done.toSet()).apply(); renderDay() })
        content.addView(text("Safety: warm up wrists and shoulders. Practise handstands in clear space and learn a safe exit. Stop for sharp pain.", 12f, muted).apply { setPadding(dp(2), dp(14), dp(2), dp(10)) })
    }

    private fun updateHeader() { /* completion is shown at the bottom of each day */ }
    private fun formatTime(s: Int) = String.format("%02d:%02d", s / 60, s % 60)
    private fun startTimer(seconds: Int) {
        timer?.cancel()
        remaining = seconds.coerceAtLeast(0)
        if (!::timerText.isInitialized) return
        timerText.text = formatTime(remaining)
        timerButton.text = "Pause timer"
        timer = object : CountDownTimer(remaining * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) { remaining = ((millisUntilFinished + 999) / 1000).toInt(); timerText.text = formatTime(remaining) }
            override fun onFinish() { remaining = 0; timerText.text = "DONE!"; timerButton.text = "Start again"; Toast.makeText(this@MainActivity, "Rest finished — ready for the next set!", Toast.LENGTH_SHORT).show() }
        }.start()
        timerButton.setOnClickListener {
            timer?.cancel(); timer = null; timerButton.text = "Resume timer"
            timerButton.setOnClickListener { startTimer(remaining) }
        }
    }

    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
